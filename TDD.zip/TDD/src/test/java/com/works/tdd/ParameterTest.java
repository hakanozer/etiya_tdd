package com.works.tdd;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import actions.ParameterClass;

@RunWith(value = Parameterized.class)
public class ParameterTest {
	
	@Rule
	public PrintRule printRule = new PrintRule();
	
	@Parameter(value = 0)
	public int a;
	@Parameter(value = 1)
	public int b;
	@Parameter(value = 2)
	public int expected;
	
	/*
	public ParameterTest(int a, int b, int expected) {
		super();
		this.a = a;
		this.b = b;
		this.expected = expected;
	}*/

	
	@Parameters
	public static Collection<Object[]> data(){
		Object[][] arrays = { { 5,5,20 }, { 10,5,50 }, { 7,5,35 } }; 
		return Arrays.asList(arrays);
	}
	

	@Test
	public void testCall() {
		System.out.println("testCall Start");
		assertEquals(expected, ParameterClass.call(a, b));
		System.out.println("testCall End");
	}

	@Test
	public void testOther() {
		System.out.println("== testOther ==");
	}

}
