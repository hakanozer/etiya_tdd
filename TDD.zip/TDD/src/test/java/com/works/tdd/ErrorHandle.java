package com.works.tdd;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ErrorHandle {
	
	@Rule
	public ExpectedException ex = ExpectedException.none();

	@Test(expected = NullPointerException.class)
	public void testNullPointer() {
		System.out.println("testNullPointer start");
		Integer number = null;
		number.intValue();
		System.out.println("testNullPointer end");
	}
	
	@Test(expected = IndexOutOfBoundsException.class)
	public void testBounds( ) {
		String[] arr = { "Mehmet", "Ali", "Suna" };
		String item = arr[4];
	}
	
	@Test( expected = Exception.class )
	public void globalException() {
		call();
		System.out.println("globalException start");
		int i = 1 / 0;
		System.out.println("globalException end");
	}
	
	public void call() {
		System.out.println("Call call");
	}

	
	@Test
	public void globalTestException() {
		System.out.println("globalTestException start");
		ex.expect(IndexOutOfBoundsException.class);
		ex.expectMessage("index :0, Size : 0");
		new ArrayList<String>().get(0);
		System.out.println("globalTestException end");
	}
	
}
