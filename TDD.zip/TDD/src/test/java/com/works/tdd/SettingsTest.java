package com.works.tdd;

import static org.junit.Assert.*;

import org.junit.Test;

import actions.Settings;

public class SettingsTest {
	
	Settings st = new Settings();

	@Test
	public void nameTest() {
		assertEquals("alim", st.name());
	}

}
