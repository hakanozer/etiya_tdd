package com.works.tdd;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class CustomRuleTest {

	
	@Rule
	public PrintRule printRule = new PrintRule();

	@Test
	public void testPrintRule() {
		int i = 10;
		assertEquals(10, 10);
	}
	
	@Test(expected = Exception.class)
	@Deprecated
	public void testSum() {
		int i = 1 / 0;
		int sm = 40;
		assertEquals(40, 40);
		System.out.println("testSum call ");
	}
	
	/*
	@Test(timeout = 500)
	public void testMinus() throws InterruptedException {
		
		Thread.currentThread().sleep(1000);
	    System.out.println("testMinus Call ");
		
	}
	*/
	

}
