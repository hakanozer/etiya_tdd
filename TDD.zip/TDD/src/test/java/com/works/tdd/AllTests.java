package com.works.tdd;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ActionTest.class, AppTest.class, LifeCircleTest.class, SettingsTest.class })
public class AllTests {

}
