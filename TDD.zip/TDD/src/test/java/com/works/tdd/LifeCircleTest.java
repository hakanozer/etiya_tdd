package com.works.tdd;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class LifeCircleTest {
	
	List<Integer> ls = new ArrayList<Integer>();

	
	public LifeCircleTest() {
		System.out.println("LifeCircleTest -1");
	}

	@Before
	public void beforeMethod() {
		System.out.println("beforeMethod -2");
	}
	
	//@BeforeClass
	public void beforeClass() {
		System.out.println("beforeClass -2");
	}
	
	
	@Test
	public void test1() {
		ls.add(10);
		System.out.println("test1 - 3");
	}
	
	@Test
	public void otherTest1() {
		ls.add(20);
		System.out.println("otherTest1 - 3");
	}
	
	
	@After
	public void after() {
		System.out.println("after - 4");
		for (Integer integer : ls) {
			System.out.println("int : " + integer);
		}
		System.out.println("=========================");
		
	}
	
	@Ignore
	public void ignore() {
		ls.add(20);
		System.out.println("ignore - 5");
	}
	
	
}
