package com.works.tdd;

import java.lang.annotation.Annotation;
import java.util.Collection;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public class PrintRule implements TestRule {

	public Statement apply(final Statement base, final Description description) {
		
		Statement statement = new Statement() {
			
			@Override
			public void evaluate() throws Throwable {
				long start = System.currentTimeMillis();
				System.out.println(description.getMethodName() + " " + "Start...");
				
				base.evaluate();
				
				Collection<Annotation> annotations = description.getAnnotations();
				for (Annotation item : annotations) {
					System.out.println(item.toString());
				}
				
				System.out.println(description.getMethodName() + " " + "End... " + description.getClassName());
				long end = System.currentTimeMillis();
				long between = end - start;
				System.out.println(between);
			}
		};
		
		return statement;
	}

	

}
