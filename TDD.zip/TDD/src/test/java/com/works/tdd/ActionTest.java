package com.works.tdd;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.Test;

import actions.ActionImpl;

public class ActionTest {
	
	ActionImpl action = new ActionImpl();
	
	// assertEquals -> if
	@Test
	public void fncAssertEquals() {
		long start = System.currentTimeMillis();
		System.out.println("sumTest start");
		int sm = action.sum(40, 50);
		assertEquals("assertEquals message Error", 90, sm);
		System.out.println("sumTest End");
		long end = System.currentTimeMillis();
		long between = end - start;
		System.out.println("between : " + between);
	}
	
	
	@Test
	public void assertTrueFalse() {
		int sm = action.sum(40, 50);
		//assertTrue("assertEquals message Error", sm == 90);
		assertTrue("assertEquals message Error", action.fncStatus());
		assertFalse(action.fncStatus());
	}
	
	@Test
	public void assertNull() {
		Integer min = action.minus(90, 60);
		assertNotNull(min);
		
		Random rd = null;
		assertNotNull(rd);
	}
	
	@Test
	public void assertSame() {
		Integer sm1 = action.sum(40, 50);
		Integer sm2 = sm1;
		Integer sm3 = 130;
		
		assertNotSame(sm1, sm2); // aynı nesneleri işaret eder
		assertNotSame(sm2, sm3); // farklı nesneleri işaret eder
	}
	
	
	@Test
	public void assertArray() {
		String[] arr1 = { "İstanbul", "İzmir", "Bursa" }; 
		String[] arr2 = { "İstanbul", "İzmiR", "Bursa" };
		assertArrayEquals(arr1, arr2);
	}

}
