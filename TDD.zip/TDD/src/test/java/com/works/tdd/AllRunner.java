package com.works.tdd;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class AllRunner {
	
	public static void main(String[] args) {
		
		Result result = JUnitCore.runClasses(ActionTest.class, LifeCircleTest.class, SettingsTest.class);
		for (Failure fail : result.getFailures()) {
			//System.out.println(fail.getTestHeader());
			//System.out.println(fail.getMessage());
			//System.out.println(fail.getTrace());
			System.out.println(fail.toString());
		}
		
	}

}
