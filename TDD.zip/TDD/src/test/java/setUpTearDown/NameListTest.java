package setUpTearDown;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class NameListTest {
	
	public List<User> ls = new ArrayList<>();


	// single call
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass Call");
	}
	
	// @Test size call
	@Before
	public void setUp() throws Exception {
		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setMail("mail@mail.com"+i);
			us.setName("Ali"+i);
			ls.add(us);
		}
	}

	
	@Test
	public void test1() {
		ls.add(new User( "Zehra", "zehra@mail.com" ));
		System.out.println("test1 Call -- " + ls.get(1).getName());
	}

	
	@Test
	public void test2() {
		System.out.println("test-2 Call -- " + ls.get(10).getName());
	}
	
	// @Test size call
	@After
	public void tearDown() throws Exception {
		System.out.println("@After Call");
		ls =  null;
	}
	
	// single call
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass Call");
	}
	

}
