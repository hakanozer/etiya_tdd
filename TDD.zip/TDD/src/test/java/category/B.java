package category;

import org.junit.Test;
import org.junit.experimental.categories.Category;

@Category(FunctionTest.class)
public class B {
	
	// PerformanceAllTestsSuite or FunctionAllTestsSuite call
	@Category(PerformanceTest.class)
	@Test
	public void printB() {
		System.out.println("PerformanceTest or FunctionTest printB() -- ");
	}
	
	@Test
	public void printBB() {
		System.out.println("FunctionTest printBB()");
	}

}
