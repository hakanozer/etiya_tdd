package category;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.experimental.categories.Category;

public class A {

	@Test
	public void test() {
		fail();
	}
	
	@Category(PerformanceTest.class)
	@Test
	public void printA() {
		System.out.println("PerformanceTest printA()");
	}
	
	@Category(FunctionTest.class)
	@Test
	public void printAA() {
		System.out.println("FunctionTest printAA()");
	}
	

}
