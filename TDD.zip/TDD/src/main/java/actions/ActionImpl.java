package actions;

public class ActionImpl implements IAction {

	public int sum(int a, int b) {
		try {
			Thread.sleep(1500);
		} catch (Exception e) {}
		return a + b;
	}

	public int minus(int a, int b) {
		return a - b;
	}

	public String read(String data) {
		return "Name: " +data;
	}

	public boolean fncStatus() {
		return false;
	}

}
