package actions;

public interface IAction {
	
	int sum( int a, int b );
	int minus( int a, int b );
	String read( String data );
	boolean fncStatus();

}
