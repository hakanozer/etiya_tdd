package actions;

public class Settings {
	
	public String name() {
		return "ali";
	}

}
