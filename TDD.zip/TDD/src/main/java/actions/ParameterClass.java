package actions;

public class ParameterClass {

	public static int call(int a, int b)
	{		
		return a*b;
	}
	
}
