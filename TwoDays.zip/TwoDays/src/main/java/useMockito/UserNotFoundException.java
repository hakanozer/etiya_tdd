package useMockito;

public class UserNotFoundException extends Exception {
	
	public UserNotFoundException() {
		super();
	}
	
	
	public UserNotFoundException(String message) {
		super(message);
	}
	
	
	public UserNotFoundException(String message, Throwable throwable) {
		super(message, throwable);
	}
	
	
	public UserNotFoundException(Throwable throwable) {
		super(throwable);
	}

}
