package useMockito;

public interface IUserService {
	
	boolean autUser( final User user ) throws UserNotFoundException;

}
