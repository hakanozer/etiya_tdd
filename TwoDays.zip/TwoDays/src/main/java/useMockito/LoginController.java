package useMockito;

import java.io.Serializable;

public class LoginController implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private IUserService iUserService;
	public LoginController( IUserService iUserService ) {
		this.iUserService = iUserService;
	}
	
	public String userLogin( final User user ) {
		try {
			if ( iUserService.autUser(user) ) {
				return "dashboard";
			}else {
				return "login?statu=false";
			}
		} catch (UserNotFoundException e) {
			return "error?status=false";
		}
	}

	
	
}
