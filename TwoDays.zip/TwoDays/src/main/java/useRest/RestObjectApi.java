package useRest;

import org.jsoup.Jsoup;

import com.google.gson.Gson;

public class RestObjectApi {
	
	public static Product pr = new Product();
	

	public RestObjectApi() {
		
		try {
			String url = "http://jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
			String data = Jsoup.connect(url).timeout(30000).ignoreContentType(true).get().body().text();
			
			Gson gson = new Gson();
			JsonData jsonData = gson.fromJson(data, JsonData.class);
			pr = jsonData.getProducts().get(0);
			/*
			for (Bilgiler item : jsonData.getProducts().get(0).getBilgiler()) {
				System.out.println(item.getProductName());
			}
			*/
		} catch (Exception e) {
			System.err.println("Api Error : " + e);
		}
		
	}

}
