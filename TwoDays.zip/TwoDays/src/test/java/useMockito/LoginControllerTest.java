package useMockito;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.Times;

public class LoginControllerTest {
	
	@Mock
	private IUserService iUserService;
	
	@InjectMocks
	private LoginController loginController;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	
	@Test
	public void userLoginTest() throws UserNotFoundException {
		
		final User userStub = new User();
		userStub.setUsername("admin");
		userStub.setPassword("12345");
		
		Mockito.when(iUserService.autUser(userStub)).thenReturn(true);
		
		final String redirect = loginController.userLogin(userStub);
		assertEquals("dashboard", redirect);
		
		//Mockito.verify(iUserService, new Times(1)).autUser(Mockito.any(User.class));
	}
	

}
