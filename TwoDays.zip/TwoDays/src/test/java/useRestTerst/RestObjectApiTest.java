package useRestTerst;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import useRest.RestObjectApi;

class RestObjectApiTest {
	
	
	
	@Test
	void restTimeTest() {
		new RestObjectApi();
	}

	@Test
	void restStatusTest() {
		assertEquals(true, RestObjectApi.pr.getDurum());
	}
	
	
	@Test
	void restCountProductTest() {
		assertEquals(12, RestObjectApi.pr.getBilgiler().size() );
	}

}
