package useRestAssured;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.junit.Assert.*;

import java.util.List;

import javax.management.DescriptorKey;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;


public class MmdbapiTest {

	String url = "http://www.omdbapi.com";
	private RequestSpecification request;
	
	@Before
	public void setUp() {
		request = RestAssured.given();
		request.baseUri(url);
		request
		.param("apikey", "53b70b9d")
		.param("s", "Never back")
		.param("r", "json")
		.param("page", "1")
		.param("v", "1");
	}
	
	@Test
	@DisplayName("Action 200 code control")
	public void testRequestStatus() {
		 Response res = request.when().get().andReturn();
		 ResponseBody body = res.body();
		 //System.out.println(body.asString());
		request.when().get(url).then().statusCode(HttpStatus.SC_OK);
	}
	
	@Test
	public void testYearControl() {
	
		List<Object> values = request.when().get()
			    .then().extract().jsonPath()
			    .getList("Search.Year");
		for (Object item : values) {
			if (item.equals("2016")) {
				assertEquals(item, "2016");
				break;
			}
			
		}
		
		//ValidatableResponse obj = request.get().then().body("totalResults", equalTo("45"));
		//System.out.println(obj.toString());
		
	}

}
